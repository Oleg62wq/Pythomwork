#define _POSIX_C_SOURCE 200809L
#define _DEFAULT_SOURCE
#include "io.h"
#include "protocol.h"
#include "mecanum.h"
#include <math.h>
#include <time.h>
#include <termios.h>
#include <fcntl.h>
#include <unistd.h>
#include <poll.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
uint64_t rhc_now_ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000ull+(uint64_t)t.tv_nsec;}
int rhc_parse_odom(char *line,RHC_Odom *out){
 RHC_Odom o={0};char *f[RHC_MAX_FIELDS];int n=rhc_unpack(line,f);
 if(n!=24||strcmp(f[0],"O1"))return 0;
 if(!rhc_u32(f[1],&o.seq)||!rhc_u32(f[2],&o.tick))return 0;
 int32_t v;for(int i=0;i<3;i++){if(!rhc_i32(f[3+i],&v))return 0;o.actual[i]=v*1e-6;}
 for(int i=0;i<4;i++){if(!rhc_i32(f[6+i],&v))return 0;o.wheels[i]=v*1e-6;if(fabs(o.wheels[i])>2*ROBOT_WHEEL_MAX)return 0;}
 if(!rhc_u32(f[10],&o.mask)||o.mask>15)return 0;
 for(int i=0;i<4;i++)if(!rhc_u32(f[11+i],&o.ages[i])||!rhc_u32(f[15+i],&o.counts[i]))return 0;
 if(!rhc_u32(f[19],&o.session)||!rhc_u32(f[20],&o.ack)||!rhc_u32(f[21],&o.flags))return 0;
 uint32_t r,l;if(!rhc_u32(f[22],&r)||!rhc_u32(f[23],&l))return 0;
 if(r!=(uint32_t)lround(ROBOT_R*1e6)||l!=(uint32_t)lround(ROBOT_L*1e6))return 0;
 double fk[3];mecanum_forward(o.wheels,fk);
 for(int i=0;i<3;i++)if(fabs(fk[i]-o.actual[i])>2e-5)return 0;
 *out=o;return 1;
}
static uint32_t le32(const unsigned char *p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static uint64_t le64(const unsigned char *p){return (uint64_t)le32(p)|(uint64_t)le32(p+4)<<32;}
static float lef(const unsigned char *p){uint32_t v=le32(p);float f;memcpy(&f,&v,4);return f;}
int rhc_parse_sensors(const unsigned char *b,size_t len,uint64_t now,RHC_Sensors *out){
 if(len<42||memcmp(b,"RHC1",4))return 0;
 uint32_t n=le32(b+36);if(n>RHC_MAX_OBSTACLES||len!=42+8*(size_t)n)return 0;
 uint16_t crc=(uint16_t)b[len-2]|(uint16_t)b[len-1]<<8;
 if(rhc_crc16((const char*)b,len-2)!=crc)return 0;
 RHC_Sensors s={0};s.seq=le32(b+4);s.target_ns=le64(b+8);s.obstacle_ns=le64(b+16);
 /* CLOCK_MONOTONIC from this same Pi, actual acquisition timestamps. */
 if(!s.target_ns||!s.obstacle_ns||s.target_ns>now||s.obstacle_ns>now||
  now-s.target_ns>250000000ull||now-s.obstacle_ns>300000000ull)return 0;
 s.d=lef(b+24);s.phi=lef(b+28);s.confidence=lef(b+32);s.n=n;
 if(!isfinite(s.d)||!isfinite(s.phi)||!isfinite(s.confidence)||s.d<=0||s.d>30||
  fabs(s.phi)>3.141593||s.confidence<0||s.confidence>1)return 0;
 for(size_t i=0;i<n;i++){s.points[i].x=lef(b+40+8*i);s.points[i].y=lef(b+44+8*i);
  if(!isfinite(s.points[i].x)||!isfinite(s.points[i].y)||fabs(s.points[i].x)>50||fabs(s.points[i].y)>50)return 0;}
 *out=s;return 1;
}
int rhc_serial_open(const char *path){
 int fd=open(path,O_RDWR|O_NOCTTY|O_NONBLOCK|O_CLOEXEC);if(fd<0)return -1;
 struct termios t;if(tcgetattr(fd,&t)<0){close(fd);return -1;}cfmakeraw(&t);
 cfsetispeed(&t,B115200);cfsetospeed(&t,B115200);
 t.c_cflag=(t.c_cflag&~(PARENB|CSTOPB|CSIZE|CRTSCTS))|CS8|CLOCAL|CREAD;
 t.c_cc[VMIN]=0;t.c_cc[VTIME]=0;
 if(tcsetattr(fd,TCSANOW,&t)<0){close(fd);return -1;}tcflush(fd,TCIOFLUSH);return fd;
}
int rhc_send_payload(int fd,const char *payload){
 char line[128];size_t n=strlen(payload);if(n>sizeof(line)-7)return -1;
 int len=snprintf(line,sizeof(line),"%s*%04X\n",payload,(unsigned)rhc_crc16(payload,n));
 size_t sent=0;uint64_t deadline=rhc_now_ns()+20000000ull;
 while(sent<(size_t)len){ssize_t k=write(fd,line+sent,(size_t)len-sent);
  if(k>0){sent+=(size_t)k;continue;}
  if(k<0&&errno!=EAGAIN&&errno!=EINTR)return -1;
  if(rhc_now_ns()>=deadline)return -1;
  struct pollfd p={fd,POLLOUT,0};if(poll(&p,1,2)<0&&errno!=EINTR)return -1;
 }return 0;
}
