#include "interrupt_USART.hpp"
unsigned char rx_char;
volatile bool uart_rx_fault=false;
static constexpr uint16_t N=512;
static volatile uint16_t head=0,tail=0;
static uint8_t ring[N];
static bool discard_line=false;
void rx_callback(UART_HandleTypeDef *huart){
 if(huart->Instance!=USART1)return;
 uint16_t next=(head+1)&(N-1);
 if(next==tail)uart_rx_fault=true;
 else{ring[head]=rx_char;__DMB();head=next;}
 HAL_UART_Receive_IT(huart,&rx_char,1);
}
bool uart_read_line(char *dst,size_t cap){
 static char partial[128];static size_t used=0;
 if(uart_rx_fault){
  uint32_t pm=__get_PRIMASK();__disable_irq();tail=head;__set_PRIMASK(pm);
  used=0;discard_line=true;uart_rx_fault=false;
 }
 while(tail!=head){uint8_t c=ring[tail];__DMB();tail=(tail+1)&(N-1);
  if(c=='\r')continue;
  if(c=='\n'){
   if(discard_line){discard_line=false;used=0;continue;}
   if(!used)continue;
   if(used>=cap){used=0;continue;}
   for(size_t i=0;i<used;i++)dst[i]=partial[i];
   dst[used]=0;used=0;return true;
  }
  if(discard_line)continue;
  if(used>=sizeof(partial)-1){discard_line=true;used=0;continue;}
  partial[used++]=(char)c;
 }
 return false;
}
extern "C" void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart){
 if(huart->Instance!=USART1)return;
 __HAL_UART_CLEAR_FLAG(huart,UART_CLEAR_OREF|UART_CLEAR_NEF|UART_CLEAR_FEF|UART_CLEAR_PEF);
 uart_rx_fault=true;
 HAL_UART_Receive_IT(huart,&rx_char,1);
}
