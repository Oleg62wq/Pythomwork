# STM32 production firmware

See ../README_RU.md and ../docs/PROTOCOL.md. Target: STM32G474RE / NUCLEO-G474RE.
Build: make (GNU Arm Embedded GCC >= 11). Shared headers are in ../common.
The original pin assignments and PI gains are retained, but motor-to-wheel
labels follow the executable original IK, not its inconsistent old README.
Use the provided Makefile. The supplied .ioc is an original pin reference,
not an authoritative description of the modified application or HSI clock.
