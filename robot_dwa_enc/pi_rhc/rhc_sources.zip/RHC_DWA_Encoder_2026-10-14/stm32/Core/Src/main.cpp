/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* Based on the supplied STMicroelectronics Cube project; ST notices and
 * peripheral driver licenses are retained in their original source files. */
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "Motor/Motor.hpp"
#include "HallSensor/HallSensor.hpp"
#include "PWM_pin/PWM_pin.hpp"
#include "interrupts/interrupt_USART.hpp"
#include "mecanum.h"
#include "protocol.h"
#include "packet_builder.h"
#include <cstring>
#include <cmath>
void SystemClock_Config(void);
PWM_pin pa0(&htim2,TIM_CHANNEL_1),pa1(&htim2,TIM_CHANNEL_2);
PWM_pin pb10(&htim2,TIM_CHANNEL_3),pb11(&htim2,TIM_CHANNEL_4);
PWM_pin pa6(&htim3,TIM_CHANNEL_1),pa4(&htim3,TIM_CHANNEL_2);
PWM_pin pb0(&htim3,TIM_CHANNEL_3),pb1(&htim3,TIM_CHANNEL_4);
HallSensor h1(&htim4,TIM_CHANNEL_1,GPIOB,GPIO_PIN_6);
HallSensor h2(&htim4,TIM_CHANNEL_2,GPIOB,GPIO_PIN_7);
HallSensor h3(&htim4,TIM_CHANNEL_3,GPIOB,GPIO_PIN_8);
HallSensor h4(&htim4,TIM_CHANNEL_4,GPIOB,GPIO_PIN_9);
Motor m1(&pa1,&pa0,&h1,ROBOT_HALL_EDGES_PER_REV);
Motor m2(&pb10,&pb11,&h2,ROBOT_HALL_EDGES_PER_REV);
Motor m3(&pa6,&pa4,&h3,ROBOT_HALL_EDGES_PER_REV);
Motor m4(&pb1,&pb0,&h4,ROBOT_HALL_EDGES_PER_REV);
Motor *motors[4]={&m1,&m2,&m3,&m4};
HallSensor *sensors[4]={&h1,&h2,&h3,&h4};
constexpr int map[4]={ROBOT_MOTOR1_WHEEL,ROBOT_MOTOR2_WHEEL,ROBOT_MOTOR3_WHEEL,ROBOT_MOTOR4_WHEEL};
constexpr int polarity[4]={ROBOT_MOTOR1_POLARITY,ROBOT_MOTOR2_POLARITY,ROBOT_MOTOR3_POLARITY,ROBOT_MOTOR4_POLARITY};
static uint32_t session=0,ack=0,tseq=0,last_cmd=0,last_tel=0;
static bool session_valid=false,have_seq=false,timeout_stop=true;
static double request_wheels[4]={0},applied_wheels[4]={0};
static uint32_t last_drive=0;
static uint32_t flags=8; // bit3: sign inferred from drive history, never measured by Hall
static char tx[RHC_LINE_MAX];
static void stop_all(){
 for(int i=0;i<4;i++){motors[i]->set_speed(0);request_wheels[i]=applied_wheels[i]=0;}
}
static bool newer(uint32_t a,uint32_t b){return a!=b&&(uint32_t)(a-b)<0x80000000u;}
static void command(char *line){
 if(std::strcmp(line,"STOP")==0||std::strcmp(line,"OFF")==0){stop_all();session_valid=false;return;}
 char *f[RHC_MAX_FIELDS];int n=rhc_unpack(line,f);uint32_t se,seq;
 if(n==2&&std::strcmp(f[0],"R1")==0&&rhc_u32(f[1],&se)){
  stop_all();session=se;session_valid=true;have_seq=false;timeout_stop=true;return;
 }
 if(n==3&&std::strcmp(f[0],"S1")==0&&rhc_u32(f[1],&se)&&rhc_u32(f[2],&seq)){
  if(!session_valid||se!=session||(have_seq&&!newer(seq,ack)))return;
  stop_all();ack=seq;have_seq=true;last_cmd=HAL_GetTick();timeout_stop=true;return;
 }
 if(n!=6||std::strcmp(f[0],"C1")!=0||!rhc_u32(f[1],&se)||!rhc_u32(f[2],&seq)||
   !session_valid||se!=session||(have_seq&&!newer(seq,ack)))return;
 int32_t v[3];for(int i=0;i<3;i++)if(!rhc_i32(f[i+3],&v[i]))return;
 if(std::abs((double)v[0])>2000000||std::abs((double)v[1])>2000000||std::abs((double)v[2])>5000000)return;
 double desired[4];mecanum_inverse(v[0]*1e-6,v[1]*1e-6,v[2]*1e-6,desired);
 // COMMON scaling: independent wheel clipping would change the body direction.
 double maxmag=0;for(int i=0;i<4;i++)if(std::fabs(desired[i])>maxmag)maxmag=std::fabs(desired[i]);
 double scale=maxmag>ROBOT_WHEEL_MAX?ROBOT_WHEEL_MAX/maxmag:1;
 flags=(flags&~2u)|(scale<1?2u:0);
 for(int i=0;i<4;i++)request_wheels[i]=desired[i]*scale;
 ack=seq;have_seq=true;last_cmd=HAL_GetTick();timeout_stop=false;
}
static void drive(uint32_t now){
 if(now-last_drive<10)return;
 double dt=(now-last_drive)*.001;last_drive=now;if(dt>.05)dt=.05;
 // Interpolate the entire wheel vector with one alpha; preserve coupled body
 // motion. This is a final actuator reference slew limiter, not fake odometry.
 double maxdelta=0;for(int i=0;i<4;i++)maxdelta=fmax(maxdelta,fabs(request_wheels[i]-applied_wheels[i]));
 double alpha=maxdelta>0?fmin(1.0,ROBOT_WHEEL_ACC*dt/maxdelta):1;
 for(int i=0;i<4;i++)applied_wheels[i]+=alpha*(request_wheels[i]-applied_wheels[i]);
 for(int i=0;i<4;i++)motors[i]->set_speed((float)(applied_wheels[map[i]]*polarity[i]));
}
static void telemetry(uint32_t now){
 if(now-last_tel<ROBOT_TELEMETRY_MS||huart1.gState!=HAL_UART_STATE_READY)return;
 double o[4]={0},body[3];uint32_t ages[4],counts[4],mask=0;
 flags&=~(1u|4u|16u|32u|64u);
 if(!session_valid)flags|=64;
 if(timeout_stop)flags|=1;
 for(int i=0;i<4;i++){
  int w=map[i];o[w]=motors[i]->get_rad_s()*polarity[i];
  ages[w]=sensors[i]->edge_age_ms();counts[w]=sensors[i]->get_pulse_count();
  if(sensors[i]->has_rpm())mask|=1u<<w;
  if(motors[i]->direction_unknown())flags|=16;
  float target=motors[i]->get_target();int dir=target>0?1:target<0?-1:0;
  if(dir&&dir!=motors[i]->get_direction())flags|=4;
 }
 for(int i=0;i<4;i++)if(!std::isfinite(o[i])||std::fabs(o[i])>2*ROBOT_WHEEL_MAX){
  flags|=32;stop_all();for(int j=0;j<4;j++)o[j]=0;break;
 }
 mecanum_forward(o,body);
 RHC_Builder b;rhc_builder_init(&b,tx,sizeof(tx));rhc_puts(&b,"O1");
 rhc_field_u32(&b,tseq);rhc_field_u32(&b,now);
 for(int i=0;i<3;i++)rhc_field_i32(&b,(int32_t)(body[i]*1e6));
 for(int i=0;i<4;i++)rhc_field_i32(&b,(int32_t)(o[i]*1e6));
 rhc_field_u32(&b,mask);
 for(int i=0;i<4;i++)rhc_field_u32(&b,ages[i]);
 for(int i=0;i<4;i++)rhc_field_u32(&b,counts[i]);
 rhc_field_u32(&b,session);rhc_field_u32(&b,ack);rhc_field_u32(&b,flags);
 rhc_field_u32(&b,(uint32_t)(ROBOT_R*1e6+.5));rhc_field_u32(&b,(uint32_t)(ROBOT_L*1e6+.5));
 int n=rhc_builder_finish(&b);if(n<0){stop_all();return;}
 if(HAL_UART_Transmit_IT(&huart1,(uint8_t*)tx,(uint16_t)n)==HAL_OK){last_tel=now;tseq++;}

}
int main(void){
 HAL_Init();SystemClock_Config();MX_GPIO_Init();MX_TIM3_Init();MX_USART1_UART_Init();MX_TIM2_Init();
 pa0.init();pa1.init();pb10.init();pb11.init();pa6.init();pa4.init();pb0.init();pb1.init();
 MX_TIM4_IC_Init();h1.init();h2.init();h3.init();h4.init();stop_all();
 HAL_UART_Receive_IT(&huart1,&rx_char,1);__HAL_RCC_CLEAR_RESET_FLAGS();iwdg_start(500);
 last_drive=last_cmd=HAL_GetTick();
 while(1){
  iwdg_feed();
  if(uart_rx_fault){stop_all();timeout_stop=true;session_valid=false;}
  char line[128];while(uart_read_line(line,sizeof(line)))command(line);
  uint32_t now=HAL_GetTick();
  if(!timeout_stop&&now-last_cmd>=ROBOT_CMD_TIMEOUT_MS){stop_all();timeout_stop=true;}
  if(!timeout_stop)drive(now);
  for(int i=0;i<4;i++)motors[i]->update();
  telemetry(now);
 }
}
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV2;
  RCC_OscInitStruct.PLL.PLLN = 18;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}


extern "C" void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){rx_callback(huart);}
extern "C" void Error_Handler(void){__disable_irq();motors_emergency_off();while(1){}}
