#define _POSIX_C_SOURCE 200809L
#include "io.h"
#include "mecanum.h"
#include "protocol.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>
#include <sys/socket.h>
#include <arpa/inet.h>
static volatile sig_atomic_t running=1;
static void quit(int sig){(void)sig;running=0;}
static int newer(uint32_t a,uint32_t b){return a!=b&&(uint32_t)(a-b)<0x80000000u;}
static int stop(int fd,uint32_t session,uint32_t seq){char b[80];snprintf(b,sizeof(b),"S1|%u|%u",session,seq);return rhc_send_payload(fd,b);}
static void usage(const char *name){fprintf(stderr,"Usage: %s --serial /dev/serial0 [--port 5555] [--drive]\nDefault: dry run; STM32 is kept stopped. UDP listens on 127.0.0.1 only.\n",name);}
int main(int argc,char **argv){
 const char *serial=NULL;int port=5555,drive=0;
 for(int i=1;i<argc;i++){
  if(!strcmp(argv[i],"--serial")&&i+1<argc)serial=argv[++i];
  else if(!strcmp(argv[i],"--port")&&i+1<argc){char *end;long v=strtol(argv[++i],&end,10);if(*end||v<1||v>65535){usage(argv[0]);return 2;}port=(int)v;}
  else if(!strcmp(argv[i],"--drive"))drive=1;else{usage(argv[0]);return 2;}
 }
 if(!serial){usage(argv[0]);return 2;}
 signal(SIGINT,quit);signal(SIGTERM,quit);signal(SIGPIPE,SIG_IGN);
 int fd=rhc_serial_open(serial);if(fd<0){perror(serial);return 1;}
 int sock=socket(AF_INET,SOCK_DGRAM|SOCK_NONBLOCK|SOCK_CLOEXEC,0);if(sock<0){perror("socket");close(fd);return 1;}
 struct sockaddr_in addr={0};addr.sin_family=AF_INET;addr.sin_port=htons((uint16_t)port);addr.sin_addr.s_addr=htonl(INADDR_LOOPBACK);
 if(bind(sock,(struct sockaddr*)&addr,sizeof(addr))<0){perror("bind");close(sock);close(fd);return 1;}
 uint32_t session=(uint32_t)(rhc_now_ns()^(uint64_t)getpid()),seq=0;
 int rnd=open("/dev/urandom",O_RDONLY);if(rnd>=0){ssize_t z=read(rnd,&session,4);(void)z;close(rnd);}
 char payload[100];snprintf(payload,sizeof(payload),"R1|%u",session);
 if(rhc_send_payload(fd,payload)<0){perror("UART init");close(fd);close(sock);return 1;}
 DwaState state;dwa_reset(&state);RHC_Odom odom={0};RHC_Sensors sensors={0};
 int have_odom=0,have_sensors=0;uint64_t odom_ns=0,next=rhc_now_ns()+90000000ull;
 char line[RHC_LINE_MAX];size_t used=0;int discard=0;unsigned frames=0;
 printf("# %s; session=%u; body=x-forward,y-left,w-CCW; sensor UDP=127.0.0.1:%d\n",drive?"DRIVE":"DRY RUN",session,port);
 printf("# time_s,mode,hold,status,vx_actual,vy_actual,w_actual,vx_cmd,vy_cmd,w_cmd,mask,age_fl,age_fr,age_rl,age_rr,reason\n");
 while(running){
  uint64_t now=rhc_now_ns();int ms=now<next?(int)((next-now+999999)/1000000):0;
  struct pollfd p[2]={{fd,POLLIN,0},{sock,POLLIN,0}};
  int result=poll(p,2,ms);if(result<0&&errno!=EINTR){perror("poll");break;}
  if(p[0].revents&(POLLERR|POLLHUP|POLLNVAL)){fprintf(stderr,"UART disconnected\n");break;}
  if(p[0].revents&POLLIN){
   unsigned char bytes[1024];ssize_t n;
   while((n=read(fd,bytes,sizeof(bytes)))>0)for(ssize_t j=0;j<n;j++){
    char c=(char)bytes[j];if(c=='\r')continue;
    if(c=='\n'){
     if(!discard&&used){line[used]=0;RHC_Odom o;
      if(rhc_parse_odom(line,&o)&&o.session==session&&(!have_odom||newer(o.seq,odom.seq))){
       odom=o;odom_ns=rhc_now_ns();have_odom=1;
      }
     }used=0;discard=0;
    }else if(!discard){if(used>=sizeof(line)-1){discard=1;used=0;}else line[used++]=c;}
   }
  }
  if(p[1].revents&POLLIN){
   unsigned char b[RHC_SENSOR_BYTES+1];ssize_t n;
   while((n=recv(sock,b,sizeof(b),0))>=0){RHC_Sensors s;
    if(rhc_parse_sensors(b,(size_t)n,rhc_now_ns(),&s)&&
     (!have_sensors||(s.target_ns>=sensors.target_ns&&s.obstacle_ns>=sensors.obstacle_ns&&
      (s.target_ns>sensors.target_ns||s.obstacle_ns>sensors.obstacle_ns||newer(s.seq,sensors.seq))))){sensors=s;have_sensors=1;}
   }
  }
  now=rhc_now_ns();if(now<next)continue;
  const char *reason="ok";
  if(now-next>90000000ull)reason="schedule_overrun";
  else if(!have_odom||now-odom_ns>150000000ull)reason="odometry_stale";
  else if(odom.flags&16u)reason="wheel_direction_unknown";
  else if(odom.flags&32u)reason="encoder_fault";
  else if(odom.flags&64u)reason="session_missing_restart_required";
  else if(!have_sensors||now-sensors.target_ns>250000000ull)reason="target_stale";
  else if(now-sensors.obstacle_ns>300000000ull)reason="lidar_stale";
  else if(sensors.confidence<=.05)reason="target_lost";
  next+=90000000ull;if(next<=now)next=now+90000000ull;
  DwaOutput out={0};out.status=DWA_BAD_INPUT;
  if(!strcmp(reason,"ok")){
   DwaInput in={0};in.d=sensors.d;in.phi=sensors.phi;in.confidence=sensors.confidence;
   memcpy(in.actual,odom.actual,sizeof(in.actual));memcpy(in.wheel_actual,odom.wheels,sizeof(in.wheel_actual));
   in.obstacles=sensors.points;in.obstacle_count=sensors.n;
   dwa_plan(&state,&in,&out);
   if(out.status==DWA_EMERGENCY)reason="no_safe_command";
   if(out.status==DWA_BAD_INPUT)reason="invalid_input";
   uint64_t end=rhc_now_ns();
   if(end-now>90000000ull||end-odom_ns>150000000ull||end-sensors.target_ns>250000000ull||end-sensors.obstacle_ns>300000000ull)
    reason="planning_deadline";
  }else dwa_reset(&state);
  int err=0;
  if(drive&&!strcmp(reason,"ok")&&out.status<DWA_EMERGENCY){
   // micro-SI keeps serial quantization below 1e-6, including small w and vy.
   snprintf(payload,sizeof(payload),"C1|%u|%u|%d|%d|%d",session,++seq,
    (int)lround(out.command[0]*1e6),(int)lround(out.command[1]*1e6),(int)lround(out.command[2]*1e6));
   err=rhc_send_payload(fd,payload);
  }else err=stop(fd,session,++seq);
  if(err<0){fprintf(stderr,"UART write failed; MCU watchdog will stop motors\n");break;}
  if((frames++%5)==0||strcmp(reason,"ok")){
   printf("%.6f,%d,%d,%d,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%u,%u,%u,%u,%u,%s\n",
    rhc_now_ns()*1e-9,out.mode,out.hold,out.status,odom.actual[0],odom.actual[1],odom.actual[2],
    out.command[0],out.command[1],out.command[2],odom.mask,odom.ages[0],odom.ages[1],odom.ages[2],odom.ages[3],reason);
   fflush(stdout);
  }
 }
 stop(fd,session,++seq);close(fd);close(sock);return 0;
}
