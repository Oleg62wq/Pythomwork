#ifndef RHC_MECANUM_H
#define RHC_MECANUM_H
#include "robot_config.h"
#ifdef __cplusplus
extern "C" {
#endif
/* x forward, y left, positive yaw counterclockwise; X roller arrangement. */
static inline void mecanum_inverse(double vx,double vy,double w,double o[4]) {
 o[W_FL]=(vx-vy-ROBOT_L*w)/ROBOT_R;
 o[W_FR]=(vx+vy+ROBOT_L*w)/ROBOT_R;
 o[W_RL]=(vx+vy-ROBOT_L*w)/ROBOT_R;
 o[W_RR]=(vx-vy+ROBOT_L*w)/ROBOT_R;
}
static inline void mecanum_forward(const double o[4],double u[3]) {
 u[0]=ROBOT_R*(o[0]+o[1]+o[2]+o[3])/4.0;
 u[1]=ROBOT_R*(-o[0]+o[1]+o[2]-o[3])/4.0;
 u[2]=ROBOT_R*(-o[0]+o[1]-o[2]+o[3])/(4.0*ROBOT_L);
}
#ifdef __cplusplus
}
#endif
#endif
