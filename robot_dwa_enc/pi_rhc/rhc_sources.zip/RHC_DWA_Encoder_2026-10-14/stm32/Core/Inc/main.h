/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* Аварийное отключение моторов: обнуляем ШИМ напрямую в регистрах таймеров.
   Работает из обработчиков исключений (HardFault и т.п.), не зависит от HAL. */
static inline void motors_emergency_off(void)
{
  TIM2->CCR1 = 0; TIM2->CCR2 = 0; TIM2->CCR3 = 0; TIM2->CCR4 = 0;
  TIM3->CCR1 = 0; TIM3->CCR2 = 0; TIM3->CCR3 = 0; TIM3->CCR4 = 0;
}

/* Независимый сторожевой таймер (IWDG), регистрами — без HAL-модуля.
   LSI ≈ 32 кГц, делитель /32 → 1 тик ≈ 1 мс. После запуска остановить нельзя:
   если iwdg_feed() не вызывается дольше timeout_ms — MCU перезагружается. */
static inline void iwdg_start(uint16_t timeout_ms)
{
  if (timeout_ms < 1U)    timeout_ms = 1U;
  if (timeout_ms > 4096U) timeout_ms = 4096U;
  DBGMCU->APB1FZR1 |= DBGMCU_APB1FZR1_DBG_IWDG_STOP;  /* не сбрасывать на брейкпоинтах */
  IWDG->KR  = 0xCCCCU;          /* запуск (включает LSI) */
  IWDG->KR  = 0x5555U;          /* разрешить запись PR/RLR */
  IWDG->PR  = 3U;               /* /32 */
  IWDG->RLR = timeout_ms - 1U;
  while (IWDG->SR != 0U) {}     /* ждём применения настроек */
  IWDG->KR  = 0xAAAAU;
}

static inline void iwdg_feed(void)
{
  IWDG->KR = 0xAAAAU;
}

/* USER CODE END EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define B1_Pin GPIO_PIN_13
#define B1_GPIO_Port GPIOC
#define B1_EXTI_IRQn EXTI15_10_IRQn
#define LPUART1_TX_Pin GPIO_PIN_2
#define LPUART1_TX_GPIO_Port GPIOA
#define LPUART1_RX_Pin GPIO_PIN_3
#define LPUART1_RX_GPIO_Port GPIOA
#define LD2_Pin GPIO_PIN_5
#define LD2_GPIO_Port GPIOA
#define T_SWDIO_Pin GPIO_PIN_13
#define T_SWDIO_GPIO_Port GPIOA
#define T_SWCLK_Pin GPIO_PIN_14
#define T_SWCLK_GPIO_Port GPIOA
#define T_SWO_Pin GPIO_PIN_3
#define T_SWO_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
