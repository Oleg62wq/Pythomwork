#ifndef RHC_DWA_H
#define RHC_DWA_H
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct { double x,y; } DwaPoint;
typedef struct {
 double d,phi,confidence;
 double actual[3];                 /* CURRENT measured vx,vy,w; never last command */
 double wheel_actual[4];           /* measured signed [FL,FR,RL,RR], rad/s */
 const DwaPoint *obstacles; size_t obstacle_count;
} DwaInput;
typedef struct {
 int initialized,stop_active;
 double x_est,y_est,lost_t,scan_sign;
} DwaState;
enum { DWA_OK=0,DWA_BRAKING=1,DWA_EMERGENCY=2,DWA_BAD_INPUT=3 };
typedef struct {
 double command[3],d_est,phi_est,cost;
 int mode,hold,status,candidates;
} DwaOutput;
void dwa_reset(DwaState *s);
int dwa_plan(DwaState *s,const DwaInput *in,DwaOutput *out);
/* For numerical regression only. Reproduces the supplied MATLAB, including
 * its unchecked SEARCH/SPIN/fallback. The daemon NEVER calls this function. */
#ifdef DWA_ENABLE_REFERENCE
int dwa_matlab_reference(DwaState *s,const DwaInput *in,DwaOutput *out);
#endif
#ifdef __cplusplus
}
#endif
#endif
