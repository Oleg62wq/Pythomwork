#include "HallSensor.hpp"
#include "robot_config.h"

// ── Статические члены класса ──────────────────────────────────────────────────

HallSensor* HallSensor::registry_[4]    = {nullptr};
uint8_t     HallSensor::registry_count_ = 0;

TIM_HandleTypeDef htim4;

// ── Инициализация базы TIM4 (вызвать один раз до hall*.init()) ────────────────

extern "C" void MX_TIM4_IC_Init(void)
{
    __HAL_RCC_TIM4_CLK_ENABLE();

    // 72 МГц / (71+1) = 1 МГц → 1 мкс на тик
    // Period = 0xFFFF: переполнение через ~65 мс (пересчитывается is_stalled)
    htim4.Instance               = TIM4;
    htim4.Init.Prescaler         = 71;
    htim4.Init.CounterMode       = TIM_COUNTERMODE_UP;
    htim4.Init.Period            = 0xFFFF;
    htim4.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
    htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;

    if (HAL_TIM_IC_Init(&htim4) != HAL_OK) {
        Error_Handler();
    }

    HAL_NVIC_SetPriority(TIM4_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(TIM4_IRQn);
}

// ── Конструктор и методы класса ───────────────────────────────────────────────

HallSensor::HallSensor(TIM_HandleTypeDef* htim, uint32_t channel, GPIO_TypeDef* port, uint16_t pin)
    : htim_(htim), channel_(channel), port_(port), pin_(pin) {}

void HallSensor::init()
{
    // Счётчик циклов для меток времени фронтов (включение идемпотентно).
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CTRL        |= DWT_CTRL_CYCCNTENA_Msk;

    __HAL_RCC_GPIOB_CLK_ENABLE();

    GPIO_InitTypeDef gpio = {};
    gpio.Pin       = pin_;
    gpio.Mode      = GPIO_MODE_AF_PP;
    gpio.Pull      = GPIO_PULLUP;
    gpio.Speed     = GPIO_SPEED_FREQ_LOW;
    gpio.Alternate = GPIO_AF2_TIM4;
    HAL_GPIO_Init(port_, &gpio);

    TIM_IC_InitTypeDef ic = {};
    ic.ICPolarity  = TIM_ICPOLARITY_BOTHEDGE;
    ic.ICSelection = TIM_ICSELECTION_DIRECTTI;
    ic.ICPrescaler = TIM_ICPSC_DIV1;
    ic.ICFilter    = 0x0F;  // фильтр дребезга: 16 выборок
    HAL_TIM_IC_ConfigChannel(htim_, &ic, channel_);

    if (registry_count_ < 4) {
        registry_[registry_count_++] = this;
    }

    HAL_TIM_IC_Start_IT(htim_, channel_);
}

// ── Публичный интерфейс ───────────────────────────────────────────────────────

float HallSensor::get_rpm(uint8_t pulses_per_rev) const
{
    if (is_stalled()) {
        cached_rpm_ = 0.0f;
        base_valid_ = false;
        rpm_valid_  = false;
        return 0.0f;
    }

    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    uint32_t edge_cyc = edge_cyc_;
    uint32_t edge_cnt = edge_cnt_;
    __set_PRIMASK(primask);

    const float clk = static_cast<float>(SystemCoreClock);

    if (!base_valid_) {                    // первый фронт после остановки — только база
        base_cyc_   = edge_cyc;
        base_cnt_   = edge_cnt;
        base_valid_ = true;
        return cached_rpm_;
    }

    uint32_t span = edge_cyc - base_cyc_;
    if (edge_cnt != base_cnt_ && span >= static_cast<uint32_t>(MIN_SPAN_S * clk)) {
        cached_rpm_ = static_cast<float>(edge_cnt - base_cnt_) * 60.0f * clk
                    / (static_cast<float>(pulses_per_rev) * static_cast<float>(span));
        base_cyc_ = edge_cyc;
        base_cnt_ = edge_cnt;
        rpm_valid_ = true;
    }

    // Если следующий фронт запаздывает, скорость не может быть выше «1 импульс за
    // прошедшее время» — показание плавно падает при торможении, а не ждёт is_stalled.
    uint32_t since = DWT->CYCCNT - edge_cyc;
    if (since > 0) {
        float cap = LATE_MARGIN * 60.0f * clk
                  / (static_cast<float>(pulses_per_rev) * static_cast<float>(since));
        if (cached_rpm_ > cap) return cap;
    }
    return cached_rpm_;
}

bool HallSensor::is_stalled(uint32_t timeout_ms) const
{
    // 4 edges/rev at 0.5 rad/s give one edge every 3.14 s. The old
    // fixed 500 ms timeout erased the estimate before the next edge.
    if (!valid_) return true;
    if (timeout_ms == 0) {
        timeout_ms = 4000;
        if (rpm_valid_ && cached_rpm_ > 0.0f) {
            float period_ms = 60000.0f / (ROBOT_HALL_EDGES_PER_REV * cached_rpm_);
            float adaptive = 1.5f * period_ms;
            if (adaptive < 250) adaptive = 250;
            if (adaptive > 4000) adaptive = 4000;
            timeout_ms = static_cast<uint32_t>(adaptive);
        }
    }
    return (HAL_GetTick() - last_capture_ms_) > timeout_ms;
}

// ── Внутренний захват (вызывается из dispatch_capture) ────────────────────────

void HallSensor::on_capture()
{
    uint32_t cnt = pulse_count_ + 1;
    pulse_count_     = cnt;
    edge_cyc_        = DWT->CYCCNT;
    edge_cnt_        = cnt;
    last_capture_ms_ = HAL_GetTick();
    valid_           = true;
}

// ── Диспетчер колбэка ─────────────────────────────────────────────────────────

void HallSensor::dispatch_capture(TIM_HandleTypeDef* htim)
{
    for (uint8_t i = 0; i < registry_count_; i++) {
        HallSensor* s = registry_[i];
        if (s->htim_ == htim && htim->Channel == channel_to_active(s->channel_)) {
            s->on_capture();
        }
    }
}

HAL_TIM_ActiveChannel HallSensor::channel_to_active(uint32_t channel)
{
    switch (channel) {
        case TIM_CHANNEL_1: return HAL_TIM_ACTIVE_CHANNEL_1;
        case TIM_CHANNEL_2: return HAL_TIM_ACTIVE_CHANNEL_2;
        case TIM_CHANNEL_3: return HAL_TIM_ACTIVE_CHANNEL_3;
        case TIM_CHANNEL_4: return HAL_TIM_ACTIVE_CHANNEL_4;
        default:            return HAL_TIM_ACTIVE_CHANNEL_CLEARED;
    }
}

// ── HAL колбэк (переопределяет weak-символ из stm32g4xx_hal_tim.c) ───────────

extern "C" void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef* htim)
{
    HallSensor::dispatch_capture(htim);
}
