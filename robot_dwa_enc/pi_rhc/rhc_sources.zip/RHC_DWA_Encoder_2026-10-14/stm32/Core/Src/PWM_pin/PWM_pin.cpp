extern "C" {
#include "PWM_pin.hpp"


PWM_pin::PWM_pin(TIM_HandleTypeDef* htim_prt, unsigned int channel)
    : htim(htim_prt), TIM_Channel(channel){}

void PWM_pin::init(){
    HAL_TIM_PWM_Start(htim, TIM_Channel);
}

void PWM_pin::set_compare(uint16_t speed){
    if (speed > PWM_LIMIT) speed = PWM_LIMIT;
    __HAL_TIM_SET_COMPARE(htim, TIM_Channel, speed);
}
}