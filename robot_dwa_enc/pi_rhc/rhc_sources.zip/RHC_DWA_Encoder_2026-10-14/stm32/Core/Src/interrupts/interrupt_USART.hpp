#pragma once
#include "usart.h"
#include <cstddef>
#include <cstdint>
extern unsigned char rx_char;
extern volatile bool uart_rx_fault;
void rx_callback(UART_HandleTypeDef *huart);
bool uart_read_line(char *dst,size_t cap);
