#ifndef RHC_ROBOT_CONFIG_H
#define RHC_ROBOT_CONFIG_H
/* SI units. Shared by STM32 and Pi; hardware wiring follows the EXECUTABLE
 * MecanumIK.cpp in the supplied project, not its inconsistent README. */
#define ROBOT_R 0.075
#define ROBOT_LX 0.245
#define ROBOT_LY 0.180
#define ROBOT_L (ROBOT_LX + ROBOT_LY)
#define ROBOT_WHEEL_MAX 25.51
#define ROBOT_WHEEL_ACC 22.92
#define ROBOT_AX 1.719
#define ROBOT_AY 1.719
#define ROBOT_AW 4.04
#define ROBOT_PLAN_TS 0.09
#define ROBOT_HALL_EDGES_PER_REV 4
#define ROBOT_TELEMETRY_MS 30u
#define ROBOT_CMD_TIMEOUT_MS 350u
#define ROBOT_SENSOR_TIMEOUT_MS 500u
/* Software order (canonical MATLAB): [FL, FR, RL, RR]. */
enum { W_FL=0, W_FR=1, W_RL=2, W_RR=3 };
/* Physical motor1..4 -> canonical index. Verify on the lifted chassis. */
#define ROBOT_MOTOR1_WHEEL W_FR
#define ROBOT_MOTOR2_WHEEL W_RR
#define ROBOT_MOTOR3_WHEEL W_FL
#define ROBOT_MOTOR4_WHEEL W_RL
#define ROBOT_MOTOR1_POLARITY 1
#define ROBOT_MOTOR2_POLARITY 1
#define ROBOT_MOTOR3_POLARITY 1
#define ROBOT_MOTOR4_POLARITY 1
/* PWM_LIMIT=400 and the supplied PI gains are intentionally retained. */
#endif
