Sources used by rhc_start.sh (state as built on the Pi)

rhc_start.sh                      - the start script (installs, builds, flashes with --flash, runs)
omp_patch.py                      - same OpenMP patch that rhc_start.sh applies to dwa.c

Documents/scripts/follow_rhc.py   - camera + Hailo + tracker + fusion -> UDP -> rhc_dwa   (written by Claude)
Documents/control/rhc_sensor_bridge.py - UDP sender (from the guys' archive, unchanged)

RHC_DWA_Encoder_2026-10-14/       - from the guys' archive:
  raspberry_pi/src/dwa.c          - DWA; candidate loop replaced by the OpenMP version (OMP_PATCH),
                                    everything else unchanged (vycap = .03 here)
  raspberry_pi/src/main.c, io.c   - unchanged; with --max-age N the script replaces
                                    250000000ull / 300000000ull by N ms before building
  raspberry_pi/include, Makefile, run.sh, tools/  - unchanged
  common/                         - robot_config.h (geometry, motor map), mecanum.h, protocol - unchanged
  stm32/                          - firmware sources (without Drivers/ HAL) - unchanged
                                    (PWM_LIMIT = 400 in Core/Src/PWM_pin/PWM_pin.hpp)
  flash_openocd.sh                - flashes firmware/RHC_G474RE_encoders.hex (used by --flash)

Not in this zip (used from the Pi as they are): tracker/, fusion/, control/bridge.py,
control/stream.py, robot.json, lidar_reset.py, HAL drivers, prebuilt firmware .hex/.bin.

Build by hand (same as the script):
  cd RHC_DWA_Encoder_2026-10-14/raspberry_pi && CFLAGS="-O2 -fopenmp" make build/rhc_dwa
