#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "stm32g4xx_hal.h"

#ifdef __cplusplus
}
#endif

#include "../PWM_pin/PWM_pin.hpp"
#include "../HallSensor/HallSensor.hpp"
#include <cstdint>

// Один объект = один мотор с PI-регулятором скорости.
//
// set_speed(rad_s) — принимает рад/с (выход MecanumIK.wheel_speeds).
// update()         — одна итерация PI; вызывать в каждом проходе main loop.
// set_gains(kp,ki) — настройка коэффициентов под конкретный мотор.

class Motor
{
public:
    Motor(PWM_pin* pin1, PWM_pin* pin2, HallSensor* sensor,
          uint8_t pulses_per_rev = 2, int16_t max_speed = PWM_LIMIT);  // max_speed обрезается до PWM_LIMIT

    void init();
    void set_speed(float target_rad_s);  // рад/с — выход MecanumIK
    void set_gains(float kp, float ki, float kd = 0.0f);
    float get_kp() const { return kp; }
    float get_ki() const { return ki; }
    float get_kd() const { return kd; }
    float get_target() const { return target_rad_s; }
    float get_output() const { return last_output; }   // последний выход регулятора (ШИМ)
    void update();                          // вызывать в main loop
    float get_rad_s() const;
    float get_rpm() const;
    /* Unsigned Hall magnitude, for the PI loop and reversal interlock. */
    float get_magnitude_rad_s() const;
    bool direction_unknown() const;
    int8_t get_direction() const { return measured_dir; }
    void stop();
    void set_PWM(int16_t pwm);                  // -PWM_LIMIT..PWM_LIMIT

private:
    PWM_pin*    pin1;
    PWM_pin*    pin2;
    HallSensor* sensor;
    uint8_t     pulses_per_rev;
    int16_t     MAX_SPEED;

    float    target_rad_s   = 0.0f;
    float    integral       = 0.0f;
    uint32_t last_update_ms = 0;
    int8_t   measured_dir   = 0;
    int8_t   prev_dir       = 0;   // -1, 0, 1

    float kp = 2.0f;
    float ki = 30.0f;
    float kd = 0.0f;           // D по измерению (без выброса при смене уставки)
    float prev_actual = 0.0f;
    float last_output = 0.0f;

    // 2π / 60 — перевод RPM → рад/с
    static constexpr float RAD_PER_RPM = 0.10471975f;
    // Предел шага регулятора: при задержке main loop dt не раздувает интеграл
    static constexpr float MAX_DT_S = 0.1f;
};
