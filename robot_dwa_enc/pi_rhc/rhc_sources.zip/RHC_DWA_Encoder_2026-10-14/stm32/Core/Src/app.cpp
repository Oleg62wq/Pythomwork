#include "app.hpp"

// extern "C" {

void setup() {
    

    
}

void loop() {
    // motor1.set_speed(1000);
}

// }