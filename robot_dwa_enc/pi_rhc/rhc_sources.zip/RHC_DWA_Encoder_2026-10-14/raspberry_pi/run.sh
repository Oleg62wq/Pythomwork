#!/bin/sh
set -eu
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
case "$(uname -m)" in
 aarch64|arm64) program="$script_dir/bin/rhc_dwa_aarch64" ;;
 armv7l|armv8l) program="$script_dir/bin/rhc_dwa_armhf" ;;
 *) make -C "$script_dir"; program="$script_dir/build/rhc_dwa" ;;
esac
chmod +x "$program"
exec "$program" "$@"
