#!/bin/sh
set -eu
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec openocd -f interface/stlink.cfg -f target/stm32g4x.cfg -c "program {$script_dir/RHC_G474RE_encoders.hex} verify reset exit"
