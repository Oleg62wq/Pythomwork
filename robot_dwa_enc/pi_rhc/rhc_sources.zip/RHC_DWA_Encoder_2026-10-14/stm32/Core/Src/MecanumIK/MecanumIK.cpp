#include "MecanumIK.hpp"
#include "mecanum.h"
void MecanumIK::calculate(float vx,float vy,float w) {
 double o[4]; mecanum_inverse(vx,vy,w,o);
 wheel_speeds[0]=o[ROBOT_MOTOR1_WHEEL]*ROBOT_MOTOR1_POLARITY;
 wheel_speeds[1]=o[ROBOT_MOTOR2_WHEEL]*ROBOT_MOTOR2_POLARITY;
 wheel_speeds[2]=o[ROBOT_MOTOR3_WHEEL]*ROBOT_MOTOR3_POLARITY;
 wheel_speeds[3]=o[ROBOT_MOTOR4_WHEEL]*ROBOT_MOTOR4_POLARITY;
}
