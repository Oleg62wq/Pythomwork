"""Sensor-process adapter. No external Python dependencies; algorithm is C.
Call send_frame ONLY with actual target and obstacle acquisition timestamps
from time.monotonic_ns() on this Pi, never refresh an old measurement's age.
"""
import math
import socket
import struct
import time


def crc16(data):
    c = 0xFFFF
    for b in data:
        c ^= b << 8
        for _ in range(8):
            c = ((c << 1) ^ (0x1021 if c & 0x8000 else 0)) & 0xFFFF
    return c


class SensorBridge:
    def __init__(self, port=5555):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.destination = ("127.0.0.1", port)
        self.seq = time.monotonic_ns() & 0xFFFFFFFF

    def send_frame(self, d, phi, confidence, obstacles, *, target_time_ns,
                   obstacle_time_ns):
        """d [m], phi [rad], confidence [0..1], obstacles Nx2 [m] in BODY.
        x forward, y left, phi positive left. Wheel odometry is NOT supplied
        here: the daemon obtains it exclusively from the STM32 UART.
        """
        points = [(float(x), float(y)) for x, y in obstacles]
        if len(points) > 4096:
            raise ValueError("At most 4096 obstacle points; do not blindly drop lidar points")
        if not (math.isfinite(d) and d > 0 and math.isfinite(phi)
                and abs(phi) <= math.pi and 0 <= confidence <= 1):
            raise ValueError("Invalid target measurement")
        if not all(math.isfinite(x) and math.isfinite(y) for x, y in points):
            raise ValueError("Invalid obstacle coordinates")
        now = time.monotonic_ns()
        if not (0 < target_time_ns <= now and 0 < obstacle_time_ns <= now):
            raise ValueError("Use acquisition CLOCK_MONOTONIC timestamps from the same Pi")
        data = struct.pack("<4sIQQfffI", b"RHC1", self.seq, target_time_ns,
                           obstacle_time_ns, d, phi, confidence, len(points))
        data += b"".join(struct.pack("<ff", x, y) for x, y in points)
        data += struct.pack("<H", crc16(data))
        self.sock.sendto(data, self.destination)
        self.seq = (self.seq + 1) & 0xFFFFFFFF

    def close(self):
        self.sock.close()
