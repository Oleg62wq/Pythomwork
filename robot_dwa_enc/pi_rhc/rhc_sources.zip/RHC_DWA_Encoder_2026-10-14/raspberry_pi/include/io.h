#ifndef RHC_IO_H
#define RHC_IO_H
#include "dwa.h"
#include <stdint.h>
#define RHC_MAX_OBSTACLES 4096
#define RHC_SENSOR_BYTES (40+8*RHC_MAX_OBSTACLES+2)
typedef struct {
 uint32_t seq,tick,session,ack,flags,mask,ages[4],counts[4];
 double actual[3],wheels[4];
} RHC_Odom;
typedef struct {
 uint32_t seq;uint64_t target_ns,obstacle_ns;
 double d,phi,confidence;size_t n;DwaPoint points[RHC_MAX_OBSTACLES];
} RHC_Sensors;
uint64_t rhc_now_ns(void);
int rhc_parse_odom(char *line,RHC_Odom *o);
int rhc_parse_sensors(const unsigned char *data,size_t n,uint64_t now,RHC_Sensors *s);
int rhc_serial_open(const char *path);
int rhc_send_payload(int fd,const char *payload);
#endif
