#!/usr/bin/env python3
"""Read/verify O1 telemetry using the Python standard library. Never moves motors.
Do not run simultaneously with rhc_dwa: only one process owns the UART.
"""
import argparse
import os
import select
import termios
from rhc_sensor_bridge import crc16

p = argparse.ArgumentParser()
p.add_argument("--serial", default="/dev/serial0")
a = p.parse_args()
fd = os.open(a.serial, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
t = termios.tcgetattr(fd)
t[0] = t[1] = t[3] = 0
t[2] = termios.CS8 | termios.CLOCAL | termios.CREAD
t[4] = t[5] = termios.B115200
t[6][termios.VMIN] = t[6][termios.VTIME] = 0
termios.tcsetattr(fd, termios.TCSANOW, t)
os.write(fd, b"STOP\n")
buffer = b""
try:
    while True:
        if not select.select([fd], [], [], 1)[0]:
            continue
        chunk = os.read(fd, 1024)
        if not chunk:
            raise RuntimeError("UART disconnected")
        buffer += chunk
        while b"\n" in buffer:
            line, buffer = buffer.split(b"\n", 1)
            try:
                body, crc = line.rstrip(b"\r").rsplit(b"*", 1)
                if len(crc) != 4 or int(crc, 16) != crc16(body):
                    print("Bad CRC"); continue
                f = body.decode("ascii").split("|")
                if len(f) != 24 or f[0] != "O1":
                    continue
                v = [int(x) for x in f[1:]]
                print(f"tick={v[1]} ms; vx={v[2]/1e6:+.4f} vy={v[3]/1e6:+.4f} "
                      f"w={v[4]/1e6:+.4f}; wheels FL FR RL RR="
                      f"{[round(x/1e6, 3) for x in v[5:9]]}; "
                      f"mask={v[9]:04b}; edge_age_ms={v[10:14]}; counts={v[14:18]}; "
                      f"flags={v[20]}")
            except (ValueError, UnicodeError):
                print("Malformed line")
        if len(buffer) > 384:
            buffer = b""
except KeyboardInterrupt:
    pass
finally:
    os.write(fd, b"STOP\n")
    os.close(fd)
