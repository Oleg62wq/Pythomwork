#ifndef RHC_PACKET_BUILDER_H
#define RHC_PACKET_BUILDER_H
#include "protocol.h"
/* Fixed buffer writer for MCU telemetry; no stdio or heap initialization. */
typedef struct {char *p;size_t cap,n;int failed;} RHC_Builder;
static inline void rhc_builder_init(RHC_Builder *b,char *p,size_t cap){b->p=p;b->cap=cap;b->n=0;b->failed=cap==0;if(cap)p[0]=0;}
static inline void rhc_put(RHC_Builder *b,char c){if(b->n+1>=b->cap){b->failed=1;return;}b->p[b->n++]=c;b->p[b->n]=0;}
static inline void rhc_puts(RHC_Builder *b,const char *s){while(*s)rhc_put(b,*s++);}
static inline void rhc_put_u32(RHC_Builder *b,uint32_t v){char digits[10];unsigned n=0;do{digits[n++]=(char)('0'+v%10);v/=10;}while(v);while(n)rhc_put(b,digits[--n]);}
static inline void rhc_field_u32(RHC_Builder *b,uint32_t v){rhc_put(b,'|');rhc_put_u32(b,v);}
static inline void rhc_field_i32(RHC_Builder *b,int32_t v){rhc_put(b,'|');if(v<0){rhc_put(b,'-');rhc_put_u32(b,(uint32_t)(-(int64_t)v));}else rhc_put_u32(b,(uint32_t)v);}
static inline int rhc_builder_finish(RHC_Builder *b){
 if(b->failed)return -1;
 uint16_t c=rhc_crc16(b->p,b->n);rhc_put(b,'*');
 const char *h="0123456789ABCDEF";for(int i=12;i>=0;i-=4)rhc_put(b,h[(c>>i)&15]);rhc_put(b,'\n');
 return b->failed?-1:(int)b->n;
}
#endif
