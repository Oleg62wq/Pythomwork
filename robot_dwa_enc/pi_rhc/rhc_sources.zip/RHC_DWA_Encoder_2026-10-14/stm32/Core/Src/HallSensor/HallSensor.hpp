#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "stm32g4xx_hal.h"

void MX_TIM4_IC_Init(void);
extern void Error_Handler(void);

#ifdef __cplusplus
}
#endif

#include <cstdint>

// Один объект = один канал TIM4 Input Capture + один пин датчика Холла.
// Пины: PB6 (CH1), PB7 (CH2), PB8 (CH3), PB9 (CH4) — все AF2/TIM4.
//
// Использование:
//   HallSensor hall1(&htim4, TIM_CHANNEL_1, GPIOB, GPIO_PIN_6);
//   MX_TIM4_IC_Init();   // один раз перед hall*.init()
//   hall1.init();
//   float rpm = hall1.get_rpm(4);   // 4 = число импульсов на оборот
//
// Метод: по времени между фронтами. ISR запоминает метку времени каждого фронта
// (32-битный DWT->CYCCNT, такт ядра), get_rpm() делит число импульсов на точное время
// между первым и последним фронтом базы (не короче 20 мс). Скорость не квантуется
// шагом «1 импульс за окно». TIM4 для меток не используется: он 16-битный и
// переполняется быстрее, чем идут импульсы на малой скорости (баг периодного метода).
// CYCCNT переполняется раз в ~59.65 с при 72 МГц; вычитание беззнаковое, а раньше
// сработает is_stalled().

extern TIM_HandleTypeDef htim4;

class HallSensor
{
public:
    HallSensor(TIM_HandleTypeDef* htim, uint32_t channel, GPIO_TypeDef* port, uint16_t pin);

    void  init();
    float get_rpm(uint8_t pulses_per_rev = 4) const;
    bool  is_stalled(uint32_t timeout_ms = 0) const;
    uint32_t edge_age_ms() const { return valid_ ? HAL_GetTick() - last_capture_ms_ : UINT32_MAX; }
    // true — после остановки уже есть хотя бы одно измерение скорости
    // (фронты пошли и набралась база MIN_SPAN_S). До этого get_rpm() отдаёт 0.
    bool  has_rpm() const { return rpm_valid_; }

    // Диагностика: сырой счётчик фронтов и текущий уровень на пине.
    uint32_t get_pulse_count() const { return pulse_count_; }
    bool     read_pin() const { return HAL_GPIO_ReadPin(port_, pin_) == GPIO_PIN_SET; }

    // Вызывается из HAL_TIM_IC_CaptureCallback — диспетчеризует по каналам.
    static void dispatch_capture(TIM_HandleTypeDef* htim);

private:
    TIM_HandleTypeDef* htim_;
    uint32_t      channel_;
    GPIO_TypeDef* port_;
    uint16_t      pin_;

    volatile uint32_t pulse_count_     = 0;  // накапливается в ISR
    volatile uint32_t last_capture_ms_ = 0;  // для is_stalled
    volatile bool     valid_           = false;

    volatile uint32_t edge_cyc_ = 0;         // DWT->CYCCNT последнего фронта
    volatile uint32_t edge_cnt_ = 0;         // pulse_count_ на этом фронте

    mutable uint32_t base_cyc_   = 0;        // начало текущей базы измерения
    mutable uint32_t base_cnt_   = 0;
    mutable bool     base_valid_ = false;
    mutable float    cached_rpm_ = 0.0f;
    mutable bool     rpm_valid_  = false;    // cached_rpm_ — реальное измерение

    static constexpr float MIN_SPAN_S  = 0.02f;  // минимальная база измерения
    static constexpr float LATE_MARGIN = 1.5f;  // допуск на неравномерность фронтов

    void on_capture();

    static HallSensor* registry_[4];
    static uint8_t     registry_count_;

    static HAL_TIM_ActiveChannel channel_to_active(uint32_t channel);
};
