
#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "stm32g4xx_hal.h"
#include <cstdint>

// Жёсткий предел ШИМ (из 1000 = период TIM2/TIM3) для всех выходов.
// set_compare() не запишет в регистр больше, что бы ни вычислил алгоритм.
constexpr uint16_t PWM_LIMIT = 400;

class PWM_pin{
    public:
    PWM_pin(TIM_HandleTypeDef* htim_prt, unsigned int channel);
    void init();
    void set_compare(uint16_t speed);
    
    private:
    TIM_HandleTypeDef* htim;
    uint32_t TIM_Channel;
};


#ifdef __cplusplus
}
#endif