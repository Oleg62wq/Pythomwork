#pragma once
#include "robot_config.h"
class MecanumIK {
public:
    float wheel_speeds[4] = {0,0,0,0}; // motor1..4, not canonical order
    void calculate(float vx,float vy,float omega);
};
