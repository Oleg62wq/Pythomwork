#ifndef RHC_PROTOCOL_H
#define RHC_PROTOCOL_H
#include <stdint.h>
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
/* ASCII payload + '*' + four hexadecimal CRC16-CCITT-FALSE digits + '\n'.
 * CRC covers only the payload, init=0xffff, poly=0x1021. No heap, locale,
 * printf-floats, or dynamic C++ library dependencies on the STM32. */
#define RHC_LINE_MAX 384
#define RHC_MAX_FIELDS 26
static inline uint16_t rhc_crc16(const char *s,size_t n) {
 uint16_t c=0xffff;
 for(size_t i=0;i<n;i++){c^=(uint16_t)(uint8_t)s[i]<<8;
  for(unsigned k=0;k<8;k++) c=(uint16_t)((c&0x8000)?(c<<1)^0x1021:c<<1);}
 return c;
}
static inline int rhc_hex(char c) {
 if(c>='0'&&c<='9')return c-'0';
 if(c>='A'&&c<='F')return c-'A'+10;
 if(c>='a'&&c<='f')return c-'a'+10;
 return -1;
}
/* Strip checksum and split in place. Empty fields and trailing junk fail. */
static inline int rhc_unpack(char *line,char *fields[RHC_MAX_FIELDS]) {
 size_t n=0;while(line[n]){if(n>=RHC_LINE_MAX-1)return -1;n++;}
 if(n&&line[n-1]=='\n')line[--n]=0;
 if(n&&line[n-1]=='\r')line[--n]=0;
 if(n<6||line[n-5]!='*')return -1;
 unsigned h=0;for(size_t i=n-4;i<n;i++){int v=rhc_hex(line[i]);if(v<0)return -1;h=(h<<4)|(unsigned)v;}
 if(rhc_crc16(line,n-5)!=h)return -1;
 line[n-5]=0;unsigned count=1;fields[0]=line;
 for(size_t i=0;i<n-5;i++)if(line[i]=='|'){
  if(!i||line[i-1]==0||count==RHC_MAX_FIELDS)return -1;
  line[i]=0;fields[count++]=line+i+1;}
 if(!*fields[count-1])return -1;
 return (int)count;
}
static inline int rhc_i32(const char *s,int32_t *out) {
 int neg=0;uint32_t v=0;size_t i=0;
 if(s[0]=='-'){neg=1;i++;}if(!s[i])return 0;
 uint32_t cap=neg?2147483648u:2147483647u;
 for(;s[i];i++){if(s[i]<'0'||s[i]>'9')return 0;unsigned d=(unsigned)(s[i]-'0');
  if(v>(cap-d)/10u)return 0;
  v=v*10u+d;}
 *out=neg?(v==2147483648u?INT32_MIN:-(int32_t)v):(int32_t)v;return 1;
}
static inline int rhc_u32(const char *s,uint32_t *out) {
 uint32_t v=0;if(!*s)return 0;
 for(size_t i=0;s[i];i++){if(s[i]<'0'||s[i]>'9')return 0;unsigned d=(unsigned)(s[i]-'0');
  if(v>(UINT32_MAX-d)/10u)return 0;
  v=v*10u+d;}*out=v;return 1;
}
#ifdef __cplusplus
}
#endif
#endif
