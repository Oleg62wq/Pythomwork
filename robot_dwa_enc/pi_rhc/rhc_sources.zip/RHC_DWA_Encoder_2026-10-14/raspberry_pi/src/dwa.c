#include "dwa.h"
#include "mecanum.h"
#include <math.h>
#include <string.h>
#include <float.h>
#define PI 3.14159265358979323846
#define DEG (PI/180.0)
static double sq(double x){return x*x;}
static double clamp(double x,double lo,double hi){return fmin(fmax(x,lo),hi);}
static double robust(double z){return z*z/(1.0+fabs(z));}
static void window(double prev,double caplo,double caphi,double a,double *lo,double *hi){
 *lo=fmax(caplo,prev-a*ROBOT_PLAN_TS);*hi=fmin(caphi,prev+a*ROBOT_PLAN_TS);
 if(*lo>*hi){if(prev>caphi)*hi=*lo=prev-a*ROBOT_PLAN_TS;
  else if(prev<caplo)*lo=*hi=prev+a*ROBOT_PLAN_TS;else *lo=*hi=prev;}
}
static double cwindow(double ref,double prev,double caplo,double caphi,double a){
 double lo,hi;window(prev,caplo,caphi,a,&lo,&hi);return clamp(ref,lo,hi);
}
static void brake(const double u[3],double cmd[3]){
 double o[4];mecanum_inverse(u[0],u[1],u[2],o);
 double alpha=1.0,a[3]={ROBOT_AX,ROBOT_AY,ROBOT_AW};
 for(int i=0;i<3;i++)alpha=fmin(alpha,a[i]*ROBOT_PLAN_TS/fmax(fabs(u[i]),1e-12));
 for(int i=0;i<4;i++)alpha=fmin(alpha,ROBOT_WHEEL_ACC*ROBOT_PLAN_TS/fmax(fabs(o[i]),1e-12));
 alpha=clamp(alpha,0,1);for(int i=0;i<3;i++)cmd[i]=(1-alpha)*u[i];
 if(fmax(fabs(cmd[0]),fmax(fabs(cmd[1]),fabs(cmd[2])))<1e-10)memset(cmd,0,3*sizeof(double));
}
/* In production raw encoder wheel speeds impose the acceleration bound,
 * including a wheel-space residual not recoverable from the three body DOFs. */
static int wheels_ok(const DwaInput *in,const double cmd[3],int reference){
 double o[4],p[4];mecanum_inverse(cmd[0],cmd[1],cmd[2],o);
 if(reference)mecanum_inverse(in->actual[0],in->actual[1],in->actual[2],p);
 else memcpy(p,in->wheel_actual,sizeof(p));
 for(int i=0;i<4;i++)if(fabs(o[i])>ROBOT_WHEEL_MAX+(reference?0:1e-9)||
   fabs(o[i]-p[i])/ROBOT_PLAN_TS>ROBOT_WHEEL_ACC+(reference?0:1e-9))return 0;
 return 1;
}
/* Original Euler rollout and objective. floor(1.20/0.05) is intentionally 23
 * for IEEE binary64, exactly as in the supplied source (not silently 24). */
static int rollout(const DwaState *s,const DwaInput *in,const double cmd[3],
 double qphi,double qy,double qd,double qvis,int objective,double *cost){
 double xr=0,yr=0,th=0,xt=s->x_est,yt=s->y_est,J=0;
 const double dt=.05;const int N=(int)floor(1.20/dt);
 /* Check the current footprint too; original checked only future poses. */
 if(!objective)for(size_t q=0;q<in->obstacle_count;q++){
  const DwaPoint p=in->obstacles[q];
  if(isfinite(p.x)&&isfinite(p.y)&&hypot(p.x,p.y)-.30<.05)return 0;
 }
 for(int n=0;n<N;n++){
  double vx=cmd[0],vy=cmd[1],w=cmd[2];
  double xd=vx*cos(th)-vy*sin(th),yd=vx*sin(th)+vy*cos(th);
  xr+=xd*dt;yr+=yd*dt;th+=w*dt;
  double xtd=-vx+w*yt,ytd=-vy-w*xt;xt+=xtd*dt;yt+=ytd*dt;
  if(objective){
   double dk=sqrt(xt*xt+yt*yt),ph=atan2(yt,xt);
   if(xt<=0)J+=300*sq((-xt)/.05)*dt;
   J+=qphi*robust(ph/(10*DEG))*dt+qy*robust(yt/.05)*dt;
   double wd=qd/(1+sq(fabs(ph)/(35*DEG)));
   J+=wd*robust((dk-.60)/.06)*dt;
   if(fabs(ph)>20*DEG)J+=qvis*sq((fabs(ph)-20*DEG)/(15*DEG))*dt;
   if(fabs(ph)>60*DEG)return 0;
  }
  for(size_t q=0;q<in->obstacle_count;q++){
   const DwaPoint p=in->obstacles[q];if(isnan(p.x))continue;
   double dx=xr-p.x,dy=yr-p.y,dist2=dx*dx+dy*dy;
   if(dist2>=.55*.55)continue;
   double clear=sqrt(dist2)-.30;
   if(clear<.05)return 0;
   if(clear<.25)J+=35*sq((.25-clear)/.25)*dt;
  }
 }
 *cost=J;return 1;
}
void dwa_reset(DwaState *s){memset(s,0,sizeof(*s));s->x_est=.60;s->scan_sign=1;}
static int emergency(DwaOutput *o,int status){memset(o->command,0,sizeof(o->command));o->status=status;return status;}
static int fallback_brake(DwaState *s,const DwaInput *in,DwaOutput *o){
 double J;brake(in->actual,o->command);o->status=DWA_BRAKING;
 /* If a wheel residual makes the common braking vector infeasible, forcing a
  * pretend acceleration bound would be wrong. Emit explicit emergency STOP. */
 if(!wheels_ok(in,o->command,0)||!rollout(s,in,o->command,0,0,0,0,0,&J))
  return emergency(o,DWA_EMERGENCY);
 return o->status;
}
static int plan_impl(DwaState *s,const DwaInput *in,DwaOutput *out,int reference){
 memset(out,0,sizeof(*out));out->cost=INFINITY;
 if(!s||!in)return emergency(out,DWA_BAD_INPUT);
 for(int i=0;i<3;i++)if(!isfinite(in->actual[i]))return emergency(out,DWA_BAD_INPUT);
 if(in->obstacle_count&&!in->obstacles)return emergency(out,DWA_BAD_INPUT);
 if(!reference){
  for(int i=0;i<4;i++)if(!isfinite(in->wheel_actual[i]))return emergency(out,DWA_BAD_INPUT);
  for(size_t q=0;q<in->obstacle_count;q++)if(!isfinite(in->obstacles[q].x)||!isfinite(in->obstacles[q].y))
   return emergency(out,DWA_BAD_INPUT);
  double fk[3];mecanum_forward(in->wheel_actual,fk);
  for(int i=0;i<3;i++)if(fabs(fk[i]-in->actual[i])>2e-5)return emergency(out,DWA_BAD_INPUT);
 }
 double vxprev=in->actual[0],vyprev=in->actual[1],wprev=in->actual[2];
 int valid=reference?(in->confidence>.05&&!isnan(in->d)&&!isnan(in->phi)):
  (isfinite(in->confidence)&&in->confidence>.05&&isfinite(in->d)&&in->d>0&&isfinite(in->phi));
 if(valid){s->x_est=in->d*cos(in->phi);s->y_est=in->d*sin(in->phi);
  s->initialized=1;s->lost_t=0;if(fabs(in->phi)>.02)s->scan_sign=in->phi>0?1:-1;
 }else{if(!s->initialized)return reference?DWA_OK:fallback_brake(s,in,out);s->lost_t+=ROBOT_PLAN_TS;}
 out->d_est=sqrt(s->x_est*s->x_est+s->y_est*s->y_est);out->phi_est=atan2(s->y_est,s->x_est);
 double ph=out->phi_est;
 if(!valid)s->stop_active=0;
 else if(s->stop_active){if(fabs(out->d_est-.60)>.060||fabs(ph)>.080)s->stop_active=0;}
 else if(fabs(out->d_est-.60)<=.025&&fabs(ph)<=.035)s->stop_active=1;
 if(s->stop_active){out->mode=1;out->hold=1;brake(in->actual,out->command);
  if(!reference){double J;if(!wheels_ok(in,out->command,0)||!rollout(s,in,out->command,0,0,0,0,0,&J))
    return emergency(out,DWA_EMERGENCY);}return out->status;
 }
 if(!valid||fabs(ph)>55*DEG){
  out->mode=valid?3:0;
  double wref=valid?2*ph:(s->lost_t<=1.2&&fabs(ph)>5*DEG?1.6*ph:s->scan_sign*.9);
  out->command[2]=cwindow(wref,wprev,-1.8,1.8,ROBOT_AW);
  if(!reference){double J;
   if(fabs(vxprev)>ROBOT_AX*ROBOT_PLAN_TS||fabs(vyprev)>ROBOT_AY*ROBOT_PLAN_TS||
     !wheels_ok(in,out->command,0)||!rollout(s,in,out->command,0,0,0,0,0,&J))
    return fallback_brake(s,in,out);
  }return out->status;
 }
 double vxf,vxb,wcap,qphi,qd,qy,qvis;int nvx,nvy,nw;
 if(fabs(ph)>35*DEG){out->mode=2;vxf=.18;vxb=.05;wcap=1.8;
  qphi=80;qd=10;qy=18;qvis=90;nvx=3;nvy=5;nw=13;
 }else{out->mode=1;vxf=.55;vxb=.20;wcap=1.6;
  qphi=30;qd=18;qy=10;qvis=50;nvx=5;nvy=5;nw=11;
 }
 double vycap=.03;
 double vxref=clamp(1.4*(s->x_est-.60),-vxb,vxf),vyref=clamp(2*s->y_est,-vycap,vycap);
 double wref=clamp(2*ph,-wcap,wcap),lo[3],hi[3];
 window(vxprev,-vxb,vxf,ROBOT_AX,&lo[0],&hi[0]);
 window(vyprev,-vycap,vycap,ROBOT_AY,&lo[1],&hi[1]);
 window(wprev,-wcap,wcap,ROBOT_AW,&lo[2],&hi[2]);
 /* OMP_PATCH: candidates in parallel, same result as the sequential loop */
 double best=1e12;int found=0,best_idx=-1,ncand=0;
 const int ntot=nvx*nvy*nw;
#ifdef _OPENMP
 #pragma omp parallel
#endif
 {
  double my_best=1e12;int my_idx=-1,my_cand=0;
#ifdef _OPENMP
  #pragma omp for schedule(dynamic,4) nowait
#endif
  for(int idx=0;idx<ntot;idx++){
   const int k=idx%nw,j=(idx/nw)%nvy,i=idx/(nw*nvy);
   double c[3]={i==nvx-1?hi[0]:lo[0]+(hi[0]-lo[0])*i/(nvx-1),
    j==nvy-1?hi[1]:lo[1]+(hi[1]-lo[1])*j/(nvy-1),
    k==nw-1?hi[2]:lo[2]+(hi[2]-lo[2])*k/(nw-1)};
   if(!wheels_ok(in,c,reference))continue;
   double J;if(!rollout(s,in,c,qphi,qy,qd,qvis,1,&J))continue;
   J+=1.20*(sq(c[0]-vxref)+1.5*sq(c[1]-vyref))+.25*sq(c[2]-wref);
   J+=sq(c[0]-vxprev)+.5*sq(c[1]-vyprev)+.4*sq(c[2]-wprev)+2*sq(c[1]);
   if(ph*c[2]<0)J+=8*sq(ph*c[2]);
   my_cand++;
   if(J<my_best){my_best=J;my_idx=idx;}
  }
#ifdef _OPENMP
  #pragma omp critical(rhc_dwa_best)
#endif
  {
   ncand+=my_cand;
   if(my_idx>=0&&(my_best<best||(my_best==best&&(best_idx<0||my_idx<best_idx)))){best=my_best;best_idx=my_idx;}
  }
 }
 out->candidates+=ncand;
 if(best_idx>=0){
  const int k=best_idx%nw,j=(best_idx/nw)%nvy,i=best_idx/(nw*nvy);
  out->command[0]=i==nvx-1?hi[0]:lo[0]+(hi[0]-lo[0])*i/(nvx-1);
  out->command[1]=j==nvy-1?hi[1]:lo[1]+(hi[1]-lo[1])*j/(nvy-1);
  out->command[2]=k==nw-1?hi[2]:lo[2]+(hi[2]-lo[2])*k/(nw-1);
  found=1;
 }
 if(found){out->cost=best;return out->status;}
 if(!reference)return fallback_brake(s,in,out);
 if(fabs(ph)>35*DEG)out->command[2]=cwindow(1.7*ph,wprev,-wcap,wcap,ROBOT_AW);
 else{out->command[0]=cwindow(vxref,vxprev,-vxb,vxf,ROBOT_AX);
  out->command[1]=cwindow(vyref,vyprev,-vycap,vycap,ROBOT_AY);
  out->command[2]=cwindow(wref,wprev,-wcap,wcap,ROBOT_AW);}
 return out->status;
}
int dwa_plan(DwaState *s,const DwaInput *in,DwaOutput *out){if(!out)return DWA_BAD_INPUT;return plan_impl(s,in,out,0);}
#ifdef DWA_ENABLE_REFERENCE
int dwa_matlab_reference(DwaState *s,const DwaInput *in,DwaOutput *out){if(!out)return DWA_BAD_INPUT;return plan_impl(s,in,out,1);}
#endif
