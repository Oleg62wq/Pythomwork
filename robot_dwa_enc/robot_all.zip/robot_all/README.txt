ROBOT: VSE CHTO SDELANO (2026-10-18)
====================================

1_RASPI_SEICHAS/   - to, chto SEICHAS rabotaet na raspe cherez rhc_start.sh
2_nashi_razrabotki/ - vse nashi faily iz repo (robot_dwa_enc), vklyuchaya pervyi stek

-------------------------------------------------------------------
1. CHTO ZAPUSKAETSYA NA RASPE (tekushii stek RHC)
-------------------------------------------------------------------
bash ~/rhc_start.sh --drive [--no-video] [--threads 2] [--max-age 400] [--flash]

  rhc_start.sh
    -> raspakovyvaet RHC_DWA_Encoder_2026-10-14 v ~/Documents
    -> stavit OpenMP patch v dwa.c (omp_patch.py vstroen v skript),
       sobiraet rhc_dwa: CFLAGS="-O2 -fopenmp" make build/rhc_dwa
    -> kladet Documents/scripts/follow_rhc.py i Documents/control/rhc_sensor_bridge.py
    -> --flash: proshivaet STM (firmware/flash_openocd.sh, nuzhen ST-Link + openocd)
    -> proveryaet proshivku STM na portu, lidar_reset.py
    -> python3 -m scripts.follow_rhc

  follow_rhc.py : kamera + Hailo + treker + lidar -> d, phi, tochki -> UDP 127.0.0.1:5555
  rhc_dwa (C)   : DWA kazhdye 0.09 s, u_prev = skorost s enkoderov (telemetriya O1 s STM),
                  komandy C1 po UART 115200 -> STM32G474
  STM           : PI-regulyatory koles, Holl, otdaet vx, vy, w obratno

  Lyudi/lidar/odometriya starshe limita (250/300/150 ms) -> STOP (reason v stroke).
  Log: ~/Documents/rhc_log.csv

-------------------------------------------------------------------
2. GDE CHTO MENYAT
-------------------------------------------------------------------
  vycap (bokovaya skorost):
    1_RASPI_SEICHAS/RHC_DWA_Encoder_2026-10-14/raspberry_pi/src/dwa.c   "double vycap=.03;"
    (na raspe: ~/Documents/RHC_DWA_Encoder_2026-10-14/raspberry_pi/src/dwa.c,
     potom prosto zapustit rhc_start.sh - on peresoberet)

  maksimalnyi ShIM:
    stm32/Core/Src/PWM_pin/PWM_pin.hpp   "constexpr uint16_t PWM_LIMIT = 400;"  (maks 999)
    sborka: sudo apt install gcc-arm-none-eabi libnewlib-arm-none-eabi libstdc++-arm-none-eabi-newlib
            nuzhna papka Drivers/ iz originalnogo arhiva parnei (zdes ee net)
            cd stm32 && make clean && make -j4 && cp build/RHC_G474RE_encoders.hex ../firmware/
            bash ~/rhc_start.sh --flash

  geometriya robota: common/robot_config.h
  chislo potokov DWA: rhc_start.sh --threads N

-------------------------------------------------------------------
3. 2_nashi_razrabotki (repo robot_dwa_enc)
-------------------------------------------------------------------
  pi_rhc/      - rhc_start.sh, follow_rhc.py, omp_patch.py, install_rhc.txt, README_RHC.md
                 (to zhe, chto v 1_RASPI_SEICHAS)
  pi/          - PERVYI stek (sei chas NE ispolzuetsya): nash DWA v4 na C + OpenMP
                 (dwa_v4_static_stop.c, libdwa4.so), dwa_py.py, nucleo.py (stroki E|...),
                 follow.py, enc_check.py, install_dwa4_enc.txt
  stm/         - blok WheelOdometry dlya STAROI proshivki Telechka_Nucleo (ne nuzhen dlya RHC)
  matlab/      - ishodnyi DWA_HumanFollower_v3_StaticTarget_Stop.m
  test/        - sverka C s Octave, bench, falshivaya STM, host-test proshivki
  tools/       - make_installer.py
  README.md    - opisanie pervogo steka

NE v arhive (berutsya na raspe kak est): tracker/, fusion/, control/bridge.py,
control/stream.py, control/robot.json, lidar_reset.py, model .hef, Drivers/ HAL dlya STM.
