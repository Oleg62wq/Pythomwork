#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "stm32g4xx_hal.h"
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

#ifdef __cplusplus
}
#endif

#include "../Src/PWM_pin/PWM_pin.hpp"
#include "../Src/Motor/Motor.hpp"
#include "../Src/interrupts/interrupt_USART.hpp"

void setup();
void loop();
