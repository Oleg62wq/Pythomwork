#include "Motor.hpp"
#include <cmath>



Motor::Motor(PWM_pin* pin1, PWM_pin* pin2, HallSensor* sensor,
             uint8_t pulses_per_rev, int16_t max_speed)
    : pin1(pin1), pin2(pin2), sensor(sensor),
      pulses_per_rev(pulses_per_rev),
      MAX_SPEED(max_speed < 0 ? 0 : max_speed > PWM_LIMIT ? PWM_LIMIT : max_speed) {}

void Motor::init()
{
    stop();
}

void Motor::set_PWM(int16_t pwm)
{
    // int32_t: -(-32768) не помещается в int16_t
    int32_t mag = pwm < 0 ? -static_cast<int32_t>(pwm) : pwm;
    if (mag > MAX_SPEED) mag = MAX_SPEED;

    if (pwm < 0)
    {
        pin1->set_compare(0);
        pin2->set_compare(static_cast<uint16_t>(mag));
    }
    else{
        pin1->set_compare(static_cast<uint16_t>(mag));
        pin2->set_compare(0);
    }
}

void Motor::set_speed(float value)
{
    if (!std::isfinite(value)) { target_rad_s = 0; stop(); return; }
    target_rad_s = value;
    // A one-channel Hall sensor has no measured sign. Do not flip the inferred
    // sign while the wheel is coasting. Stop first; latch the new direction
    // only after the sensor's conservative standstill timeout.
    int8_t requested = value > 0 ? 1 : value < 0 ? -1 : 0;
    if (requested && requested != measured_dir) {
        if (!sensor->is_stalled()) { stop(); return; }
        measured_dir = requested;
        prev_dir = requested;
        stop();
    }
    if (!requested) stop();
}

void Motor::set_gains(float kp_val, float ki_val, float kd_val){
    kp = kp_val;
    ki = ki_val;
    kd = kd_val;
    integral = 0.0f;   // старый интеграл не соответствует новым коэффициентам
}

float Motor::get_magnitude_rad_s() const
{
    return sensor->get_rpm(pulses_per_rev) * RAD_PER_RPM;
}
float Motor::get_rad_s() const
{
    return get_magnitude_rad_s() * measured_dir;
}
float Motor::get_rpm() const
{
    return sensor->get_rpm(pulses_per_rev) * measured_dir;
}
bool Motor::direction_unknown() const
{
    return measured_dir == 0 && !sensor->is_stalled();
}

void Motor::update()
{
    int8_t requested = target_rad_s > 0 ? 1 : target_rad_s < 0 ? -1 : 0;
    if (requested && requested != measured_dir) {
        if (!sensor->is_stalled()) { stop(); return; }
        measured_dir = requested;
        prev_dir = requested;
        stop();
    }
    uint32_t now = HAL_GetTick();

    // Первый шаг после старта/stop(): только запоминаем время. Иначе dt равен
    // всей паузе (секунды) и интегратор за один шаг уходит в потолок.
    if (last_update_ms == 0) {
        last_update_ms = now;
        prev_actual = get_magnitude_rad_s();
        return;
    }

    float dt = static_cast<float>(now - last_update_ms) * 0.001f;
    if (dt < 0.01f) return;  // не чаще 100 Гц
    last_update_ms = now;
    if (dt > MAX_DT_S) dt = MAX_DT_S;  // main loop мог задержаться

    float target_mag = target_rad_s > 0.0f ? target_rad_s : -target_rad_s;

    if (target_mag < 0.5f) {
        stop();
        return;
    }

    float actual_rad_s = get_magnitude_rad_s();
    float error = target_mag - actual_rad_s;

    // Колесо уже пошло (есть фронты), но скорость ещё не измерена: датчик
    // показывает 0, и интегратор вслепую накопил бы лишнее — замораживаем.
    // Пока колесо стоит (фронтов нет), копим: иначе его не сорвать с места.
    bool sensor_warming_up = !sensor->is_stalled() && !sensor->has_rpm();
    if (!sensor_warming_up) {
        integral += error * dt;
    }

    // Ограничение интегратора (anti-windup)
    if (ki > 0.0f) {
        float max_int = static_cast<float>(MAX_SPEED) / ki;
        if (integral > max_int) integral = max_int;
    }
    if (integral < 0) integral = 0;

    float d_term = kd * (prev_actual - actual_rad_s) / dt;
    prev_actual = actual_rad_s;

    float output = kp * error + ki * integral + d_term;
    if (output < 0.0f)                          output = 0.0f;
    if (output > static_cast<float>(MAX_SPEED)) output = static_cast<float>(MAX_SPEED);
    last_output = output;

    if (target_rad_s > 0.0f) {
        pin1->set_compare(static_cast<uint16_t>(output));
        pin2->set_compare(0);
    } else {
        pin1->set_compare(0);
        pin2->set_compare(static_cast<uint16_t>(output));
    }
}

void Motor::stop()
{
    pin1->set_compare(0);
    pin2->set_compare(0);
    integral = 0.0f;
    last_output = 0.0f;
    last_update_ms = 0;  // следующий update() начнёт отсчёт dt заново
}
