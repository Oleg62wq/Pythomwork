"""Integration EXAMPLE, not a replacement camera/lidar tracker.
The current upload contains no Raspberry Pi sensor application.
"""
from rhc_sensor_bridge import SensorBridge

bridge = SensorBridge()


def on_new_sensor_snapshot(distance_m, bearing_rad, confidence,
                           obstacles_body_xy, target_acquisition_ns,
                           lidar_acquisition_ns):
    # Invoke in your actual camera/lidar process after a new measurement.
    # Convert camera's right-positive angle to left-positive if necessary.
    # Transform lidar points into body coordinates (including sensor offset).
    bridge.send_frame(distance_m, bearing_rad, confidence, obstacles_body_xy,
                      target_time_ns=target_acquisition_ns,
                      obstacle_time_ns=lidar_acquisition_ns)
